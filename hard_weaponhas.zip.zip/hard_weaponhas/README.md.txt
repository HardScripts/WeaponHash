# 🔫 GetWeaponHash - Hard_Scripts
https://discord.gg/58ez92Sp65

This simple FiveM script will allow you to get the hash code of any weapon using the `/getweaponhash` command. The result will be displayed as an ox_lib notification for 10 seconds.

---

## 📦 Installation

1. Place the entire script in `resources/[local]` or another suitable folder.
2. Make sure you have [`ox_lib`](https://github.com/overextended/ox_lib) installed.
3. Add the script to `server.cfg`: