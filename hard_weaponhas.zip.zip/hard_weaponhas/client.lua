RegisterCommand("getweaponhash", function(source, args)
    if args[1] then
        local weaponHash = GetHashKey(args[1])
        print("^2Hash pre ^3" .. args[1] .. "^2 je: ^3" .. weaponHash)

        lib.notify({
            title = '🔫 WeaponHash',
            description = 'Zbraň: ' .. args[1] .. '\nHash: ' .. weaponHash,
            type = 'inform',
            duration = 10000 -- 10 seconds
        })
    else
        lib.notify({
            title = '❗ WeaponHash',
            description = 'Použitie: /getweaponhash weapon_ak47',
            type = 'error',
            duration = 10000 -- 10 sseconds
        })
    end
end, false)
