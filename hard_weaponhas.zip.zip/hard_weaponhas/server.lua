RegisterCommand("getweaponhash", function(source, args)
    if args[1] then
        local weaponHash = GetHashKey(args[1])
        print("^2Hash for ^3" .. args[1] .. "^2 is: ^3" .. weaponHash)
        
        TriggerClientEvent("weaponhash:notify", source, args[1], weaponHash)
    else
        TriggerClientEvent("weaponhash:notifyError", source)
    end
end, false)
