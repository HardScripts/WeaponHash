fx_version 'cerulean'
game 'gta5'

author 'Hard_Scripts'
description 'Get code for FiveM addon weapons'
version '1.0.0'

client_scripts {
    '@ox_lib/init.lua',
    'client.lua'
}

server_scripts {
    'server.lua'
}

lua54 'yes'
